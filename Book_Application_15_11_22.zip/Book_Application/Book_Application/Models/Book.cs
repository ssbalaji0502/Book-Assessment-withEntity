﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Book_Application.Models
{
    public class Book
    {
        public string Publisher { get; set; }
        public string Title { get; set; }
        public string AuthorLastName { get; set; }
        public string AuthorFirstName { get; set; }
        public decimal Price { get; set; }
        public string TitleOfSource { get; set; }
        public string TitleOfContainer { get; set; }
        public string PublicationDate { get; set; }
        public string Location { get; set; }
        public string JournalTitle { get; set; }
        public string VolumeNo { get; set; }
        public string IssueNo { get; set; }
        public string PageRange { get; set; }
        public string URL_DOI { get; set; }
    }

    public class Books
    {
        [Key]
        public int Id { get; set; }
        public string Publisher { get; set; }
        public string Title { get; set; }
        public int AuthorId { get; set; }
        public int MLAId { get; set; }
        public int CSMId { get; set; }
        public virtual Authors Authors { get; set; }
        public virtual MLAs MLAs { get; set; }
        public virtual CSMs CSMs { get; set; }

    }
    public class Authors
    {
        [Key]
        public int Id { get; set; }
        public string AuthorLastName { get; set; }
        public string AuthorFirstName { get; set; }
        public decimal Price { get; set; }

    }
    public class MLAs
    {
        [Key]
        public int Id { get; set; }
        public string TitleOfSource { get; set; }
        public string TitleOfContainer { get; set; }
        public DateTime PublicationDate { get; set; }
        public string Location { get; set; }

    }

    public class CSMs
    {
        [Key]
        public int Id { get; set; }
        public string JournalTitle { get; set; }
        public string VolumeNo { get; set; }
        public string IssueNo { get; set; }
        public string PageRange { get; set; }
        public string URL_DOI { get; set; }

    }
    public class BookResponse
    {
        public string Publisher { get; set; }
        public string Title { get; set; }
        public string AuthorLastName { get; set; }
        public string AuthorFirstName { get; set; }
        public decimal Price { get; set; }

    }
    public class MLAResponse
    {
        public string MLA { get; set; }
    }
    public class CMSResponse
    {
        public string CSM { get; set; }
    }
}
