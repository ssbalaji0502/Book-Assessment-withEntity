﻿using Book_Application.Models;
using System.Collections.Generic;

namespace Book_Application.Services
{
    public interface IBookServices
    {
        public List<Books> GetBooks();
        public List<Books> GetBooksWithMLA();
        public List<Books> GetBooksWithCSM();
        public IEnumerable<BookResponse> GetBookDetailsWithPublisherSP(string type);
        public IEnumerable<BookResponse> GetBookDetailsWithAuthorSP(string type);
    }
}
