﻿using Book_Application.DAL;
using Book_Application.Models;
using Book_Application.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Book_Application.Services
{
    public class BookServices : IBookServices
    {
        private BookDbContext _context;
        public BookServices(BookDbContext context)
        {
            _context = context;
        }
        public List<Books> GetBooks()
        {
            List<Books> bookList;
            try
            {
                bookList = _context.Set<Books>().Include(a => a.Authors).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return bookList;
        }

        public List<Books> GetBooksWithMLA()
        {
            List<Books> bookList;
            try
            {
                bookList = _context.Set<Books>().Include(a => a.Authors).Include(b => b.MLAs).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return bookList;
        }

        public List<Books> GetBooksWithCSM()
        {
            List<Books> bookList;
            try
            {
                bookList = _context.Set<Books>().Include(a => a.Authors).Include(b => b.CSMs).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            return bookList;
        }

        public IEnumerable<BookResponse> GetBookDetailsWithPublisherSP(string type)
        {
            IEnumerable<BookResponse> bookResponses = null;
            DALc dal = new DALc();
            DataTable dt = new DataTable();

            dt = dal.DALBookDetails(_context.Database.GetDbConnection().ConnectionString,type);
            if (dt != null && dt.Rows.Count > 0)
            {
                bookResponses = (from DataRow BK in dt.Rows
                                 select new BookResponse
                                 {
                                     Publisher = BK["Publisher"].ToString(),
                                     AuthorFirstName = BK["AuthorFirstName"].ToString(),
                                     AuthorLastName = BK["AuthorLastName"].ToString(),
                                     Price = Convert.ToDecimal(BK["Price"].ToString()),
                                     Title = BK["Title"].ToString(),
                                 }
                                 ).ToList();
            }
            return bookResponses;
        }

        public IEnumerable<BookResponse> GetBookDetailsWithAuthorSP(string type)
        {
            IEnumerable<BookResponse> bookResponses = null;
            DALc dal = new DALc();
            DataTable dt = new DataTable();

            dt = dal.DALBookDetails(_context.Database.GetDbConnection().ConnectionString, type);
            if (dt != null && dt.Rows.Count > 0)
            {
                bookResponses = (from DataRow BK in dt.Rows
                                 select new BookResponse
                                 {
                                     Publisher = BK["Publisher"].ToString(),
                                     AuthorFirstName = BK["AuthorFirstName"].ToString(),
                                     AuthorLastName = BK["AuthorLastName"].ToString(),
                                     Price = Convert.ToDecimal(BK["Price"].ToString()),
                                     Title = BK["Title"].ToString(),
                                 }
                                 ).ToList();
            }
            return bookResponses;
        }
    }
}
