﻿using Book_Application.Models;
using Microsoft.EntityFrameworkCore;

namespace Book_Application.Repository
{
    public class BookDbContext : DbContext
    {
        public BookDbContext(DbContextOptions options) : base(options) { }
        public DbSet<Books> Books { get; set; }
        public DbSet<Authors> Authors { get; set; }
        public DbSet<MLAs> MLAs { get; set; }
        public DbSet<CSMs> CSMs { get; set; }
        
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Books>()
         .HasKey(bc => new { bc.AuthorId, bc.MLAId,bc.CSMId });
            builder.Entity<Books>()
                .HasOne(bc => bc.Authors)
                .WithMany()
                .HasForeignKey(bc => bc.AuthorId);
            builder.Entity<Books>()
                .HasOne(bc => bc.MLAs)
                .WithMany()
                .HasForeignKey(bc => bc.MLAId);
            builder.Entity<Books>()
                .HasOne(bc => bc.CSMs)
                .WithMany()
                .HasForeignKey(bc => bc.CSMId);
        }
    }
}
