﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Book_Application.DAL
{
    public class DALc
    {
        public DataTable DALBookDetails(string ConnectionString, string type)
        {
            var connectionString = ConnectionString;
            DataTable dt = new DataTable();
            SqlConnection sqlCon = new SqlConnection(connectionString);
            try
            {
                sqlCon.Open();
                SqlCommand sqlCmd = new SqlCommand("sp_GetBookDetails", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@type", SqlDbType.VarChar, 20).Value = type;
                SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
                sqlDa.Fill(dt);
                sqlCon.Close();

                return dt;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlCon.Close();
            }
        }

        public string BulkInsert(string ConnectionString, DataTable dataTable)
        {
            SqlConnection sqlCon = new SqlConnection(ConnectionString);
            try
            {
                //create object of SqlBulkCopy which help to insert  
                SqlBulkCopy objbulk = new SqlBulkCopy(sqlCon);

                //assign Destination table name  
                objbulk.DestinationTableName = "BookDetails";
                objbulk.ColumnMappings.Add("Publisher", "Publisher");
                objbulk.ColumnMappings.Add("Title", "Title");
                objbulk.ColumnMappings.Add("AuthorLastName", "AuthorLastName");
                objbulk.ColumnMappings.Add("AuthorFirstName", "AuthorFirstName");
                objbulk.ColumnMappings.Add("Price", "Price");

                sqlCon.Open();
                //insert bulk Records into DataBase.  
                objbulk.WriteToServer(dataTable);
                sqlCon.Close();
                return "File Uploaded successfully";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlCon.Close();
            }
        }
    }
}
